#!/bin/sh
# t01_cmn.sh # placeholder common functions
# Articulates only for Skeleton Root patches

SKE="__SKE__" # patched (do not edit)

echo "TEST SKE: $SKE"
# .................................................................
