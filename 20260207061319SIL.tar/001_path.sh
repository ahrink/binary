#!/bin/sh
# 001_path.sh — Config Master (POSIX)
# - run once after fresh install/untar
# detect the dir in which the script itself resides
PRJ_PTH=$(cd "$(dirname "$0")" && pwd) # default SKE

search_replace() {
    # Pattern to search and replace
    local full_path="$1"; local ske_path="$2";
    local pattern='SKE="__SKE__"'
    local replacement="SKE=\"$ske_path\""
    sed -i "s|$pattern|$replacement|g" "$full_path" 2>/dev/null
}

# inventory file names only in dev eg /dev/t00_cmn.sh
exe_hardening() {
    local file=""
    local list=$(cat "${PRJ_PTH}/003_list.txt")
    for file in $(echo "$list" | tr ' ' '\n'); do
        file="${PRJ_PTH}/${file}"
        search_replace "$file" "$PRJ_PTH"
    done
}

exe_hardening
