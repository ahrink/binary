#!/bin/sh
# 002_tarExe.sh # tarball execution process

PRJ_PTH=$(cd "$(dirname "$0")" && pwd) # default SKE
TAR_lib="/home/pleb/xLibs" # hardcoded path to xLibs
TAR_stamp="$(date +%Y%m%d%H%M%S)SIL.tar"

search_replace() {
    # Pattern to search and replace
    local full_path="$1"; local ske_path="$2";
    local pattern="SKE=\"$ske_path\""
    local replacement='SKE="__SKE__"'

    sed -i "s|$pattern|$replacement|g" "$full_path" 2>/dev/null
}

pre_hardening() {
    local file=""
    local list=$(cat "${PRJ_PTH}/003_list.txt")
    for file in $(echo "$list" | tr ' ' '\n'); do
        file="${PRJ_PTH}/${file}"
        search_replace "$file" "$PRJ_PTH"
    done

    sudo tar -czf "${TAR_lib}/$TAR_stamp" .
}

pre_hardening
