#!/bin/sh
# cmn_OPPM_v001.sh
#

ahr_stamp() { date +"%Y%m%d%H%M%S%N" | cut -c 1-23; }
rSke=$(cd "$(dirname "$0")" && pwd)

D_KV="Ⓥ"  # key/value replaces = for safe eval
D_SPC="Ⓣ" # \txtdlm,  replaces blank/white spaces
D_ROW="Ⓐ" # row delimiter
D_FLD="↔"  # field delimiter (plain, semiotics-friendly)
D_TME="⧖" # \tmedlm, tme (Time Machine Efficiency)

# --- Colors (optional; safe in sh) ---
rC='\033[1;31m'; gC='\033[1;32m'; yC='\033[1;33m'
bC='\033[1;34m'; mC='\033[1;35m'; cC='\033[1;36m'
wC='\033[1;37m'; nC='\033[0m'

show_prompt() { printf "${cC}$1 ${nC}"; }
read_pause() { echo ""; show_prompt "Press Enter..."; read dummy; }

# --- Semiotic Utilities ---
D_DLM() {
    local d=""; local f="";
    while [ $# -gt 0 ]; do
        case "$1" in
            -d) d="$2"; shift 2 ;;
            -f) f="$2"; shift 2 ;;
            --) shift; break ;;
            *) break ;;
        esac
    done
    [ -n "$d" ] || { echo "ERR: -d delimiter required" >&2; return 2; }
    [ -n "$f" ] || { echo "ERR: -f fields required" >&2; return 2; }

    if [ $# -gt 0 ]; then printf '%s\n' "$1"; else cat; fi | awk -v d="$d" -v f="$f" '
        BEGIN { n = split(f, want, ",") }
        {
            c = split($0, a, d)
            out = ""
            for (i = 1; i <= n; i++) {
                k = want[i] + 0
                if (k >= 1 && k <= c) out = out (out=="" ? "" : OFS) a[k]
            }
            print out
        }'
}

# --- srcFS - search directory for pattern by file/dir type
srcFS() {
    local dir="$1"; local ptrn="$2"; local mod="$3"; local results="";

    [ "$mod" = "D" ] && results=$(ls -l "$dir" 2>/dev/null \
        | awk -v pattern="$ptrn" '$1 ~ /^d/ && $NF ~ pattern {print $NF}')

    [ "$mod" = "F" ] && results=$(ls -l "$dir" 2>/dev/null \
        | awk -v pattern="$ptrn" '$1 ~ /^-/ && $NF ~ pattern {print $NF}')

    echo "$results"
}

cfg_reader() {
    cmn_CFG=$(cat "${rSke}/DB/cfg.dlm")
    for row in $(echo "$cmn_CFG" \
    | awk -v D_ROW="$D_ROW" '{gsub(/'"$D_ROW"'/, "\n"); print}'); do

        eKV=$(echo "$row" | D_DLM -d "$D_FLD" -f "1")
        eKV=$(echo "$eKV" \
        | awk -v D_KV="$D_KV" '{gsub(/'"$D_KV"'/, "="); print}')

        key=$(echo "$eKV" | cut -d'=' -f1)
        val=$(echo "$eKV" | cut -d'=' -f2)

        eval $(echo "$key=$val")
    done
}
