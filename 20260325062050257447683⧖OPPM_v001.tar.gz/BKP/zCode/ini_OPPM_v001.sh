#!/bin/sh
# ini_OPPM_v001.sh
# Based on "pkgs_start_offline.pdf" methodology
# This script manages offline Debian/Ubuntu package repositories
#

ahr_stamp() { date +"%Y%m%d%H%M%S%N" | cut -c 1-23; }

    rSke=$(cd "$(dirname "$0")" && pwd)
    DBF_arg="${rSke}/DB"   # delimited register
    INV_arg="${rSke}/INV"  # offline repository dir
    RPT_arg="${rSke}/RPT"  # reports dir

    D_KV="Ⓥ"  # key/value replaces = for safe eval
    D_SPC="Ⓣ" # \txtdlm,  replaces blank/white spaces
    D_ROW="Ⓐ" # row delimiter
    D_FLD="↔"  # field delimiter (plain, semiotics-friendly)
    D_TME="⧖" # \tmedlm, tme (Time Machine Efficiency)

    DB_CFG="${DBF_arg}/cfg.dlm"
    DB_CUR="${DBF_arg}/base.dlm"
    DB_GHS="${DBF_arg}/ghost.dlm"
    INC_CMN="${rSke}/cmn_v001.sh"

# --- Semiotic Utilities ---
D_DLM() {
    local d=""; local f="";
    while [ $# -gt 0 ]; do
        case "$1" in
            -d) d="$2"; shift 2 ;;
            -f) f="$2"; shift 2 ;;
            --) shift; break ;;
            *) break ;;
        esac
    done
    [ -n "$d" ] || { echo "ERR: -d delimiter required" >&2; return 2; }
    [ -n "$f" ] || { echo "ERR: -f fields required" >&2; return 2; }

    if [ $# -gt 0 ]; then printf '%s\n' "$1"; else cat; fi | awk -v d="$d" -v f="$f" '
        BEGIN { n = split(f, want, ",") }
        {
            c = split($0, a, d)
            out = ""
            for (i = 1; i <= n; i++) {
                k = want[i] + 0
                if (k >= 1 && k <= c) out = out (out=="" ? "" : OFS) a[k]
            }
            print out
        }'
}

# --- srcFS - search directory for pattern by file/dir type
srcFS() {
    local dir="$1"; local ptrn="$2"; local mod="$3"; local results="";

    [ "$mod" = "D" ] && results=$(ls -l "$dir" 2>/dev/null \
        | awk -v pattern="$ptrn" '$1 ~ /^d/ && $NF ~ pattern {print $NF}')

    [ "$mod" = "F" ] && results=$(ls -l "$dir" 2>/dev/null \
        | awk -v pattern="$ptrn" '$1 ~ /^-/ && $NF ~ pattern {print $NF}')

    echo "$results"
}

cre_cache() (
  stamp=$(ahr_stamp)
  base_dir="/tmp"
  pattern="pkgs"
  INI_TMP="${base_dir}/${stamp}${D_TME}${pattern}"
  probe=$(srcFS "$base_dir" "${D_TME}${pattern}" "D")
  [ -z "$probe" ] && mkdir -p "$INI_TMP"

  DIR_TMP=$(srcFS "$base_dir" "${D_TME}${pattern}" "D")
  DIR_TMP="${base_dir}/$DIR_TMP"

  FLE_MEM="${DIR_TMP}/pkgs-index.dlm"
  pbndx=$(srcFS "$DIR_TMP" "${pattern}" "F")
  [ -z "$pbndx" ] && touch "$FLE_MEM"

  FLdump="${DIR_TMP}/pkgs-dump.dlm"
  pdump=$(srcFS "$DIR_TMP" "${pattern}" "F")
  [ -z "$pdump" ] && touch "$FLdump"
  # ...
  [ -f "$DB_CFG" ] && rm -r "$DB_CFG" && touch "$DB_CFG"
  # write configuration definition
  CFG_MEM=$(printf "%s" \
  "rSke${D_KV}${rSke}${D_FLD}Repo Project Root${D_ROW}" \
  "DBF_arg${D_KV}${DBF_arg}${D_FLD}Path To DB Files${D_ROW}" \
  "INV_arg${D_KV}${INV_arg}${D_FLD}Offline Package Inventory${D_ROW}" \
  "RPT_arg${D_KV}${RPT_arg}${D_FLD}Reports Directory${D_ROW}" \
  "DB_CFG${D_KV}${DB_CFG}${D_FLD}Configuration DB-File${D_ROW}" \
  "DB_CUR${D_KV}${DB_CUR}${D_FLD}Core Package DB-File${D_ROW}" \
  "DB_GHS${D_KV}${DB_GHS}${D_FLD}Ghost DB-File${D_ROW}" \
  "INC_CMN${D_KV}${INC_CMN}${D_FLD}Include Common Functions${D_ROW}" \
  "PTR_USE${D_KV}${pattern}${D_FLD}Cache Pattern Used${D_ROW}" \
  "FLE_MEM${D_KV}$(basename "$pmem")${D_FLD}Cache File-Pattern${D_ROW}" \
  "FLdump${D_KV}$(basename "$pdump")${D_FLD}Dump File-Pattern${D_ROW}")
  CFG_MEM=$(echo "$CFG_MEM" | awk -v D_SPC="$D_SPC" '{gsub(/ /, D_SPC); print}')

  echo "$CFG_MEM" >> "$DB_CFG"
)

runtime() {
    [ ! -f "$DB_CFG" ] && mkdir -p "$DBF_arg" "$INV_arg" "$RPT_arg"
    cre_cache
}

runtime
# iPkg=$(dpkg-query -W -f='${Package} ${Version} ${Architecture}'${D_ROW} | sed 's/ /_/g')
# echo "${iPkg}" >> "$FLdump"
