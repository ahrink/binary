#!/bin/sh
# tmp_stamp.sh
D_TME="⧖"
ahr_stamp() { date +"%Y%m%d%H%M%S%N" | cut -c 1-23; }

tmp_serial=$(ahr_stamp)"$D_TME"

echo "$tmp_serial"
