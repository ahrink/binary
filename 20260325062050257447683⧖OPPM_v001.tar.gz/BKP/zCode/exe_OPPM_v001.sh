#!/bin/sh
# exe_OPPM_v001.sh

. ./cmn_v001.sh
cfg_reader

DIR_TMP=$(srcFS "/tmp" "${D_TME}${PTR_USE}" "D")
tData="/tmp/${DIR_TMP}/${FLE_MEM}"
FLdump="/tmp/${DIR_TMP}/${FLdump}"
[ ! -f "$DB_CUR" ] && touch "$DB_CUR"
[ ! -f "$DB_GHS" ] && touch "$DB_GHS"
touch $FLdump

# get installed package short names (dpkg status)
# dpkg --get-selections | awk '$2 == "install" { print $1 }' >> "$FLdump" || exit 1

echo "F: $tData ---------------------------------------------- "
echo ""
cnt=1
ckDir="/home/xom/zXOM/cacheDEB"
for pk in $(cat "$FLdump" \
| awk -v D_ROW="$D_ROW" '{gsub(/'"$D_ROW"'/, "\n"); print}'); do
    # echo "$pk"
    ckFile=$(srcFS "$ckDir" "${pk}_" "F")
    #
    if [ -z "$ckFile" ]; then
        echo "$cnt Ghost: ${pk}"

    #else
        #echo "$cnt Found: $ckFile"
    fi
    cnt=$((cnt + 1))
done
